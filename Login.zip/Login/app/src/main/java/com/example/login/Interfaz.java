package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.TextView;
public class Interfaz extends AppCompatActivity {
    TextView receiver_msg1;
    TextView receiver_msg2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interfaz);

        receiver_msg1 = (TextView)findViewById(R.id.received_value_id1);
        receiver_msg2 = (TextView)findViewById(R.id.received_value_id2);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first activity
        String str1 = intent.getStringExtra("message_key1");
        String str2 = intent.getStringExtra("message_key2");
        String mensaje ="";
        if (str1.contentEquals("kevin")&&str2.contentEquals("321")){
            mensaje="Binvenido";
        }else{
            mensaje="user,pass incorrectos";
        }

        // display the string into textView
        receiver_msg1.setText(mensaje);
        //receiver_msg2.setText(str2);
    }
}